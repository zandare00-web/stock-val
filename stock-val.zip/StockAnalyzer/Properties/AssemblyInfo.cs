using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("StockAnalyzer")]
[assembly: AssemblyDescription("키움 OpenAPI+ + KRX OpenAPI 주식 수급 분석기")]
[assembly: AssemblyProduct("StockAnalyzer")]
[assembly: AssemblyCopyright("Copyright © 2026")]
[assembly: ComVisible(false)]
