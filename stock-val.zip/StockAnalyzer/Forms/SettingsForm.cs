using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;
using StockAnalyzer.Models;

namespace StockAnalyzer.Forms
{
    public class SettingsForm : Form
    {
        static readonly Color SIDEBAR = Color.FromArgb(30, 39, 53);
        static readonly Color TEAL = Color.FromArgb(0, 188, 180);
        static readonly Color BG = Color.FromArgb(240, 242, 247);
        static readonly Color CARD = Color.White;
        static readonly Color BRD = Color.FromArgb(228, 232, 240);
        static readonly Color TXT = Color.FromArgb(40, 48, 62);
        static readonly Color TXT2 = Color.FromArgb(120, 130, 150);

        ScoreConfig _cfg;
        TableLayoutPanel _tbl;

        public SettingsForm()
        {
            _cfg = ScoreConfig.Load();
            Text = "설정"; MinimumSize = new Size(420, 520);
            StartPosition = FormStartPosition.CenterParent;
            BackColor = BG; ForeColor = TXT; FormBorderStyle = FormBorderStyle.FixedDialog; MaximizeBox = false;

            var root = new TableLayoutPanel { Dock = DockStyle.Fill, RowCount = 3, ColumnCount = 1, BackColor = BG };
            root.RowStyles.Add(new RowStyle(SizeType.Absolute, 46));
            root.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
            root.RowStyles.Add(new RowStyle(SizeType.Absolute, 54));
            Controls.Add(root);

            // 헤더
            var hdr = new Panel { Dock = DockStyle.Fill, BackColor = SIDEBAR };
            hdr.Paint += (s, e) => { TextRenderer.DrawText(e.Graphics, "◆  설정", new Font("Segoe UI Semibold", 10.5f), new Point(16, 13), Color.White); };
            root.Controls.Add(hdr, 0, 0);

            // 본문
            var scroll = new Panel { Dock = DockStyle.Fill, AutoScroll = true, BackColor = BG, Padding = new Padding(12) };
            var cardOuter = new Panel { Dock = DockStyle.Top, AutoSize = true, BackColor = CARD, Padding = new Padding(1) };
            cardOuter.Paint += (s, e) => { using (var pen = new Pen(BRD)) e.Graphics.DrawRectangle(pen, 0, 0, cardOuter.Width - 1, cardOuter.Height - 1); };

            _tbl = new TableLayoutPanel { ColumnCount = 2, AutoSize = true, AutoSizeMode = AutoSizeMode.GrowAndShrink, Padding = new Padding(16, 8, 16, 8), BackColor = CARD };
            _tbl.ColumnStyles.Add(new ColumnStyle(SizeType.AutoSize));
            _tbl.ColumnStyles.Add(new ColumnStyle(SizeType.AutoSize));
            cardOuter.Controls.Add(_tbl);
            scroll.Controls.Add(cardOuter);
            root.Controls.Add(scroll, 0, 1);

            // ── 기업가치 (5점) ──
            Sec("VALUATION — 기업가치 (5점)");
            var perBox = Row("PER 할인율", _cfg.PerScore);
            var pbrBox = Row("PBR 할인율", _cfg.PbrScore);
            var roeBox = Row("ROE", _cfg.RoeScore);

            // ── 종목수급 (55점) ──
            Sec("STOCK SUPPLY — 종목수급 (55점)");
            var s5 = Row("외국인+기관 합계 5일", _cfg.Supply5DScore);
            var s10 = Row("외국인+기관 합계 10일", _cfg.Supply10DScore);
            var s20 = Row("외국인+기관 합계 20일", _cfg.Supply20DScore);
            var tv = Row("거래회전율 추세", _cfg.TurnoverScore);

            // ── 업종수급 (40점) ──
            Sec("SECTOR SUPPLY — 업종수급 (40점)");
            var ss5 = Row("외국인+기관 합계 5일", _cfg.SectorSupply5DScore);
            var ss10 = Row("외국인+기관 합계 10일", _cfg.SectorSupply10DScore);

            // ── 기준값 ──
            Sec("THRESHOLDS — 기준값");
            var thBox = Row("보합 기준 변화율 (%)", _cfg.TrendThresholdPct);
            var tfBox = Row("거래회전율 만점 (%)", _cfg.TurnoverFullPct);

            // ── KRX ──
            Sec("KRX OPEN API");
            var authBox = TxtRow("API 인증키", _cfg.KrxAuthKey);

            // 버튼바
            var bbar = new Panel { Dock = DockStyle.Fill, BackColor = CARD };
            bbar.Paint += (s, e) => { using (var p = new Pen(BRD)) e.Graphics.DrawLine(p, 0, 0, bbar.Width, 0); };

            var bSave = new DkBtn("저장", TEAL, Color.White, 76, 32);
            var bCancel = new DkBtn("취소", Color.FromArgb(245, 247, 252), TXT, 76, 32);
            var bReset = new DkBtn("기본값", Color.FromArgb(245, 247, 252), TXT2, 76, 32);
            bbar.Resize += (s, e) => { bSave.Location = new Point(bbar.Width - 92, 11); bCancel.Location = new Point(bbar.Width - 174, 11); bReset.Location = new Point(14, 11); };
            bbar.Controls.AddRange(new Control[] { bSave, bCancel, bReset });
            root.Controls.Add(bbar, 0, 2);

            bSave.Click += (s, e) =>
            {
                _cfg.PerScore = V(perBox);
                _cfg.PbrScore = V(pbrBox);
                _cfg.RoeScore = V(roeBox);

                _cfg.Supply5DScore = V(s5);
                _cfg.Supply10DScore = V(s10);
                _cfg.Supply20DScore = V(s20);
                _cfg.TurnoverScore = V(tv);

                _cfg.SectorSupply5DScore = V(ss5);
                _cfg.SectorSupply10DScore = V(ss10);

                _cfg.TrendThresholdPct = V(thBox);
                _cfg.TurnoverFullPct = V(tfBox);
                _cfg.KrxAuthKey = authBox.Text.Trim();

                _cfg.Save();
                DialogResult = DialogResult.OK;
                Close();
            };
            bCancel.Click += (s, e) => Close();
            bReset.Click += (s, e) =>
            {
                if (MessageBox.Show("기본값으로 초기화할까요?", "확인", MessageBoxButtons.YesNo) == DialogResult.Yes)
                { _cfg = new ScoreConfig(); _cfg.Save(); Close(); }
            };

            Load += (s, e) =>
            {
                int contentW = _tbl.PreferredSize.Width + 60;
                int contentH = _tbl.PreferredSize.Height + 46 + 54 + 60;
                Size = new Size(Math.Max(contentW, MinimumSize.Width), Math.Min(contentH, 750));
            };
        }

        void Sec(string t)
        {
            var pnl = new Panel { Height = 28, Dock = DockStyle.Fill, Margin = new Padding(0, 10, 0, 2), BackColor = Color.White };
            pnl.Paint += (s, e) =>
            {
                using (var b = new SolidBrush(TEAL)) e.Graphics.FillRectangle(b, 0, 20, 3, 8);
                TextRenderer.DrawText(e.Graphics, t, new Font("Segoe UI Semibold", 8f), new Rectangle(10, 0, 400, 28), TEAL, TextFormatFlags.VerticalCenter);
            };
            _tbl.Controls.Add(pnl); _tbl.SetColumnSpan(pnl, 2);
        }

        NumericUpDown Row(string label, double val)
        {
            _tbl.Controls.Add(new Label { Text = label, Height = 28, Width = 180, Dock = DockStyle.Fill, ForeColor = TXT2, Font = new Font("Segoe UI", 8.8f), TextAlign = ContentAlignment.MiddleLeft, BackColor = Color.White });
            var n = new NumericUpDown { Value = (decimal)val, Minimum = 0, Maximum = 100, DecimalPlaces = 1, Increment = 0.5m, Height = 26, Width = 100, BackColor = Color.FromArgb(248, 249, 252), ForeColor = TXT, BorderStyle = BorderStyle.FixedSingle, Font = new Font("Segoe UI", 8.8f) };
            _tbl.Controls.Add(n); return n;
        }

        TextBox TxtRow(string label, string val)
        {
            _tbl.Controls.Add(new Label { Text = label, Height = 28, Width = 180, Dock = DockStyle.Fill, ForeColor = TXT2, Font = new Font("Segoe UI", 8.8f), TextAlign = ContentAlignment.MiddleLeft, BackColor = Color.White });
            var t = new TextBox { Text = val ?? "", Height = 26, Width = 220, BackColor = Color.FromArgb(248, 249, 252), ForeColor = TXT, BorderStyle = BorderStyle.FixedSingle, Font = new Font("Consolas", 8.5f) };
            _tbl.Controls.Add(t); return t;
        }

        static double V(NumericUpDown n) => (double)n.Value;
    }

    // ══════════════════════════════════════════════════════════
    //  커스텀 버튼 컨트롤 — 절대 지우지 마세요!
    // ══════════════════════════════════════════════════════════
    internal sealed class DkBtn : Control
    {
        public Color Bg, Fg, Bdr;
        public int Rad = 6;
        bool _h;

        public DkBtn(string t, Color bg, Color fg, int w, int h)
        {
            Text = t; Bg = bg; Fg = fg; Bdr = Color.Empty; Size = new Size(w, h);
            Font = new Font("Segoe UI", 9f, FontStyle.Bold); Cursor = Cursors.Hand;
            SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.UserPaint | ControlStyles.DoubleBuffer | ControlStyles.SupportsTransparentBackColor, true);
            BackColor = Color.Transparent;
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            var g = e.Graphics; g.SmoothingMode = SmoothingMode.AntiAlias;
            var r = new Rectangle(0, 0, Width - 1, Height - 1);
            var bg = Enabled ? (_h ? Lt(Bg, 15) : Bg) : Color.FromArgb(226, 232, 240);
            using (var p = RR(r, Rad))
            {
                using (var b = new SolidBrush(bg)) g.FillPath(b, p);
                if (Bdr != Color.Empty) using (var pen = new Pen(Bdr)) g.DrawPath(pen, p);
            }
            TextRenderer.DrawText(g, Text, Font, r, Enabled ? Fg : Color.FromArgb(148, 163, 184), TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter);
        }

        protected override void OnMouseEnter(EventArgs e) { _h = true; Invalidate(); }
        protected override void OnMouseLeave(EventArgs e) { _h = false; Invalidate(); }

        static Color Lt(Color c, int a) => Color.FromArgb(Math.Min(255, c.R + a), Math.Min(255, c.G + a), Math.Min(255, c.B + a));
        static GraphicsPath RR(Rectangle r, int d)
        {
            var p = new GraphicsPath(); int dd = d * 2;
            p.AddArc(r.X, r.Y, dd, dd, 180, 90);
            p.AddArc(r.Right - dd, r.Y, dd, dd, 270, 90);
            p.AddArc(r.Right - dd, r.Bottom - dd, dd, dd, 0, 90);
            p.AddArc(r.X, r.Bottom - dd, dd, dd, 90, 90);
            p.CloseFigure(); return p;
        }
    }
}